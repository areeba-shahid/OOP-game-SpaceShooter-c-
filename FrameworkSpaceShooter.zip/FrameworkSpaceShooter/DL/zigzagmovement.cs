﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public class zigzagmovement : IMovement
    {
        


              private int speed;
        private Point boundary;
        private string direction;
   
       


        public zigzagmovement(int speed, Point boundary, string direction)
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
         
        }

        public Point Move(Point location)
        {

            if (direction == "right")
            {
                location.X += speed;
                location.Y += speed-5;
            }
            else if (direction == "left")
            {
                location.X -= speed;
                location.Y -= speed-5;
            }

            // Check if enemy reaches the bottom right corner
            if (location.X + speed >= boundary.X - 15 || location.Y + speed >= boundary.Y - 15)
            {
                direction = "left";
            }
            // Check if enemy reaches the top left corner
            else if (location.X - speed <= 0 && location.Y - speed <= 0)
            {
                direction = "right";
            }

            return location;
        }
    }

}
