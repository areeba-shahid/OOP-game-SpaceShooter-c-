﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using EZInput;
using System.ComponentModel;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
namespace FrameworkSpaceShooter
{
    public class enemy1bullets : Ienemy
    {
        private int speed;
        private System.Drawing.Point boundary;
     

        public enemy1bullets(int speed, System.Drawing.Point boundary)
        {
            this.speed = speed;
            this.boundary = boundary;
           

        }
        private const int TargetY = 620;
        private const int InitialYThreshold = 619;
        public System.Drawing.Point Fire(System.Drawing.Point location)
        {
           

           
                if (location.Y < InitialYThreshold)
                {
                    location.Y = Math.Min(TargetY, location.Y + speed);
                }
           

           

            return location;
        }

       
    }
}
