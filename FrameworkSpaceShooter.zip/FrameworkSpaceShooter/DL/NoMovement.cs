﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public class NoMovement : IMovement
    {
        public NoMovement()
        {

        }

        public System.Drawing.Point Move(System.Drawing.Point location)
        {
            return location;
        }
    }
}
