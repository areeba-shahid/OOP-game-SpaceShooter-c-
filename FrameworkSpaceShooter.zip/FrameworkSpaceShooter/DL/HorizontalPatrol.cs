﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace FrameworkSpaceShooter
{
   public class HorizontalPatrol :IMovement
    {

        private int speed;
        private Point boundary;
        private string direction;
        private int offset = 90;

        public HorizontalPatrol(int speed,Point boundary, string direction)
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
        }
        public Point Move(Point location)
        {
            if ((location.X + offset) >= boundary.X)
            {
                direction = "left";
            }
            else if (location.X + speed <= 0)
            {
                direction= "right";
            }
            if (direction =="left")
{
                location.X -= speed;

            }
            else
            {
                location.X += speed;

            }
            return location;

        }
    }
}
