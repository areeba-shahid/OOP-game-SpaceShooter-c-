﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Xml.Linq;

namespace FrameworkSpaceShooter
{
    public class GameObject
    {
        PictureBox pb;
        public GameObjectType Type;
        IMovement Controller;
        IPlayer Control;
        Ienemy Controll;
        
        
        public GameObject()
        {

        }
        public GameObject(Image img, GameObjectType Type, int left, int top, IMovement controller)
        {
           
            pb = new PictureBox();
            pb.Image = img;
            if (Type == GameObjectType.Ground)
            {
                pb.Width = 2000;
                pb.Height = 20;
            }
            else
            {
                pb.Width = img.Width;
                pb.Height = img.Height;
            }
            pb.BackColor = Color.Transparent;
            pb.Left = left;
            pb.Top = top;
            this.Controller = controller;
           
            this.Type = Type;
        }
        public GameObject(Image img, GameObjectType Type, int left, int top, IPlayer controls)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = left;
            pb.Top = top;
            this.Control = controls;
            this.Type = Type;

        }

        public GameObject(Image img, GameObjectType Type, int left, int top, Ienemy controll)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = left;
            pb.Top = top;
            this.Controll = controll;
            this.Type = Type;

        }
        public System.Drawing.Point Location
        {
            get { return new System.Drawing.Point(pb.Left, pb.Top); }
            set { pb.Left = value.X; pb.Top = value.Y; }
        }
        public PictureBox getpb()
        {
            return pb;
        }
       

        public void Update()
        {
            this.pb.Location = Controller.Move(this.pb.Location);
        }

      
        public void updatefire(GameObject pb)
        {

            this.pb.Location = Control.Fire(this.pb.Location);
            
        }
        public void updatefireenemy(GameObject pb)
        {

           
            this.pb.Location = Controll.Fire(this.pb.Location);
        }
    }
}
