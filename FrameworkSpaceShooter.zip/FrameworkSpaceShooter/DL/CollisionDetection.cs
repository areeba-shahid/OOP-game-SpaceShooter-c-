﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
   public class CollisionDetection
    {

        public GameObjectType objectType1;
        public GameObjectType objectType2;
        public GameAction gameAction;


        public CollisionDetection(GameObjectType type1, GameObjectType type2, GameAction action)
        {

            objectType1 = type1;
            objectType2 = type2;
            gameAction = action;

        }

       
    }
}
