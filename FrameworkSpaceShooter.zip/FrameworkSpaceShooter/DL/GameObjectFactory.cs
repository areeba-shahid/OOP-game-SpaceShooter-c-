﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public static class GameObjectFactory
    {


        private static int playerCount = 0;
        private static int horizontalCount = 0;
        private static int verticalCount = 0;
        private static int diagonalCount = 0;

       

        public static void GameObjectCount(GameObjectType type)
        {

            switch (type)
            {
                case GameObjectType.Player:
                    playerCount++;
                    break;
                case GameObjectType.horizontalenemy:
                    horizontalCount++;
                    break;
                case GameObjectType.verticalenemy:
                    verticalCount++;
                    break;
                case GameObjectType.diagonalenemy:
                    diagonalCount++;
                    break;
            }
           

        }

        public static int GetObjectCount(GameObjectType type)
        {
            switch (type)
            {
                case GameObjectType.Player:
                    return playerCount;
                case GameObjectType.horizontalenemy:
                    return horizontalCount;
                case GameObjectType.verticalenemy:
                    return verticalCount;
                case GameObjectType.diagonalenemy:
                    return diagonalCount;
               
                default:
                    return 0;
            }
        }
    }
}
