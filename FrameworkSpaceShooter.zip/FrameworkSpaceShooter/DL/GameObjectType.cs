﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public enum GameObjectType
    {
           Player,
           horizontalenemy,
        verticalenemy,
        diagonalenemy,
           PlayerBullet,
           EnemyBullet,

           PlayerHealthRestore,
           Ground

    }
}
