﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using EZInput;
using System.ComponentModel;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
namespace FrameworkSpaceShooter
{
    public class Player : IPlayer
    {
        private int speed;
        private System.Drawing.Point boundary;
        private int offset;

        public Player(int speed, System.Drawing.Point boundary, int offset) 
        {
            this.speed = speed;
            this.boundary = boundary;
            this.offset = offset;

        }






        private const int InitialYThreshold = 2;
        private const int TargetY = 1;

        public System.Drawing.Point Fire(System.Drawing.Point location)
        {
            if (location.Y > InitialYThreshold)
            {

                location.Y = Math.Max(TargetY, location.Y - speed);

            }
           
            return location;
        }


      
       
    }
}
