﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public class ChangeMovementDirection
    {

       
        public GameObjectType objectType1;
        public GameObjectType objectType2;
        public ChangeState State;


        public ChangeMovementDirection(GameObjectType type1, GameObjectType type2, ChangeState changestate)
        {

            objectType1 = type1;
            objectType2 = type2;
            State = changestate;

        }

       

    }
}
