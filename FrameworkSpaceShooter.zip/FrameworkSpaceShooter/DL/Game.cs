﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.CodeDom;
namespace FrameworkSpaceShooter
{
    public class Game 
    {

        public static Game instance;
        private static readonly object lockObject = new object();
        private List<CollisionDetection> collisions;
        private List<ChangeMovementDirection> stateList;


        private List<GameObject> gameObjectslist;
        private List<GameObject> bulletsplayer { get; set; }
        private List<GameObject> bulletsenemy { get; set; }
        private Form container;
        System.Windows.Forms.ProgressBar PlayerHealth;
        public int playerX { get; set; }
        public int playerY { get; set; }
        public int enemy1X { get; set; }
        public int enemy1Y { get; set; }
        public static Game GetInstance(Form container)
        {

            if (instance == null)
            {
                lock (lockObject)
                {
                    if (instance == null)
                    {
                        instance = new Game(container);


                    }
                }
            }
            return instance;
        }

        public Game(Form container)
        {
            this.container = container;
            gameObjectslist = new List<GameObject>();
            bulletsplayer = new List<GameObject>();
            bulletsenemy = new List<GameObject>();
            collisions = new List<CollisionDetection>();
            stateList = new List<ChangeMovementDirection>();
        }
        public Game()
        {

        }




        public void addGameObject(Image img, GameObjectType Type, int left, int top, IMovement controller)
        {
            GameObject gameObject = new GameObject(img,Type, left, top, controller);
           GameObjectFactory.GameObjectCount(Type);
            if (Type == GameObjectType.Player)
            {

                playerX = left;
                playerY = top;
                PlayerHealth = new System.Windows.Forms.ProgressBar();
                PlayerHealth.Value = 100;

                PlayerHealth.Left = playerX + 30;
                PlayerHealth.Top = playerY + 130;


                container.Controls.Add(PlayerHealth);


            }
            else if (Type == GameObjectType.horizontalenemy)
            {
                enemy1X = left;
                enemy1Y = top;
            }
            AddGameObject(gameObject);
            container.Controls.Add(gameObject.getpb());
        }

        public void addplayerbulletsasobjects(Image img, GameObjectType Type, int left, int top, IPlayer control)
        {
            GameObject gameobject = new GameObject(img,Type, left, top, control);
            PictureBox pb = gameobject.getpb();
            instance.Addbulletsplayer(gameobject);
            container.Controls.Add(gameobject.getpb());
        }
        public void addenemybulletsasobjects(Image img, GameObjectType Type, int left, int top, Ienemy control)
        {
            GameObject gameobject = new GameObject(img,  Type, left, top, control);
            PictureBox pb = gameobject.getpb();
            instance.Addenemybullets(gameobject);
            container.Controls.Add(gameobject.getpb());
            container.Controls.Add(gameobject.getpb());
        }
        public void AddGameObject(GameObject gameobject)
        {
            gameObjectslist.Add(gameobject);
        }
        public void Addbulletsplayer(GameObject gameobject)
        {
            bulletsplayer.Add(gameobject);
        }
        public void Addenemybullets(GameObject gameobject)
        {
            bulletsenemy.Add(gameobject);
        }

        public void addcollisions(CollisionDetection coll)
        {

            collisions.Add(coll);


        }

        public void addstatechange(ChangeMovementDirection change)
        {

            stateList.Add(change);


        }
        public void update()
        {
            RemoveBulletsOutsideBoundary();
            playerbulletsupdate();
            enemybulletsupdate();
            updateplayerheathlocation();
            collision1CheckingToUpdate();
            collision2CheckingToUpdate();
            collision3CheckingToUpdate();
           
            foreach (GameObject go in gameObjectslist)
            {
                go.Update();
               


                if (go.Type == GameObjectType.Player)
                {
                    // Update playerX and playerY with the player's current position
                    playerX = go.getpb().Left;
                    playerY = go.getpb().Top;
                }

                if (go.Type == GameObjectType.horizontalenemy)
                {
                    enemy1X = go.getpb().Left;
                    enemy1Y = go.getpb().Top;
                }
            }


        }
        public void updateplayerheathlocation()
        {
            PlayerHealth.Left = playerX + 30;
            PlayerHealth.Top = playerY + 130;
        }
        public void playerbulletsupdate()
        {
            
            foreach (GameObject go in bulletsplayer)
            {
                go.updatefire(go);



            }
        }
        public void enemybulletsupdate()
        {
            foreach (GameObject go in bulletsenemy)
            {

                go.updatefireenemy(go);


            }
        }

        public void RemoveBulletsOutsideBoundary()
        {

            for (int i = bulletsplayer.Count() - 1; i >= 0; i--)
            {
                GameObject bullet = bulletsplayer[i];
                if (bullet.Location.Y <= 5)
                {
                    RemovePlayerBullet(bullet);
                }
            }
            for (int i = bulletsenemy.Count() - 1; i >= 0; i--)
            {
                GameObject enemybullet = bulletsenemy[i];
                if (enemybullet.Location.Y >= 620)
                {
                    RemoveenemyBullet(enemybullet);
                }
            }


        }

        private void RemovePlayerBullet(GameObject bullet)
        {
            PictureBox pb = bullet.getpb();
            pb.Visible = false;
            container.Controls.Remove(pb);
            pb.Dispose();
            bulletsplayer.Remove(bullet); // Remove the bullet from the list
        }
        private void RemoveenemyBullet(GameObject bullet)
        {
            PictureBox pb = bullet.getpb();
            pb.Visible = false;
            container.Controls.Remove(pb);
            pb.Dispose();
            bulletsenemy.Remove(bullet); // Remove the bullet from the list
        }

        private void collision1CheckingToUpdate()
        {
            foreach (GameObject obj in gameObjectslist)
            {
                foreach (GameObject obj1 in bulletsenemy)
                {
                    if (obj.getpb().Bounds.IntersectsWith(obj1.getpb().Bounds))
                    {
                        foreach (CollisionDetection cd in collisions)
                        {
                            if (cd.objectType1 == obj.Type && cd.objectType2 == obj1.Type)
                            {

                                switch (cd.gameAction)
                                {
                                    case GameAction.DecreasePoints:
                                        if (PlayerHealth.Value >= 10)
                                        {
                                            PlayerHealth.Value -= 5;
                                        }
                                        else
                                            break;

                                        break;
                                    case GameAction.IncreasePoints:
                                        if (PlayerHealth.Value < 100)
                                        {
                                            PlayerHealth.Value += 5;
                                        }
                                        else
                                            break;
                                        break;

                                }
                            }
                        }
                    }
                }
            }
        }


        private void collision2CheckingToUpdate()
        {
            foreach (GameObject obj in gameObjectslist)
            {
                foreach (GameObject obj1 in bulletsplayer)
                {
                    if (obj.getpb().Bounds.IntersectsWith(obj1.getpb().Bounds))
                    {
                        foreach (CollisionDetection cd in collisions)
                        {
                            if (cd.objectType1 == obj.Type && cd.objectType2 == obj1.Type)
                            {

                                switch (cd.gameAction)
                                {
                                    case GameAction.DecreasePoints:
                                        if (PlayerHealth.Value >= 10)
                                        {
                                            PlayerHealth.Value -= 5;
                                        }
                                        else
                                            break;

                                        break;
                                    case GameAction.IncreasePoints:
                                        if (PlayerHealth.Value < 100)
                                        {
                                            PlayerHealth.Value += 5;
                                        }
                                        else
                                            break;
                                        break;

                                }
                            }
                        }
                    }
                }
            }
        }
        private void collision3CheckingToUpdate()
        {
            foreach (GameObject obj in gameObjectslist)
            {
                foreach (GameObject obj1 in gameObjectslist)
                {
                    if (obj.getpb().Bounds.IntersectsWith(obj1.getpb().Bounds))
                    {
                        foreach (CollisionDetection cd in collisions)
                        {
                            if (cd.objectType1 == obj.Type && cd.objectType2 == obj1.Type)
                            {

                                switch (cd.gameAction)
                                {
                                    case GameAction.DecreasePoints:
                                        if (PlayerHealth.Value >= 10)
                                        {
                                            PlayerHealth.Value -= 5;
                                        }
                                        else
                                            break;

                                        break;
                                    case GameAction.IncreasePoints:
                                        if (PlayerHealth.Value < 100)
                                        {
                                            PlayerHealth.Value += 5;
                                        }
                                        else
                                            break;
                                        break;

                                }
                            }
                        }
                    }
                }
            }
        }


        private string changeState;
        public string collisionForStateCheckingToUpdate()
        {
            foreach (GameObject obj in gameObjectslist)
            {
                foreach (GameObject obj1 in gameObjectslist)
                {
                    if (obj.getpb().Bounds.IntersectsWith(obj1.getpb().Bounds))
                    {
                        foreach (ChangeMovementDirection state in stateList)
                        {
                            if (state.objectType1 == obj.Type && state.objectType2 == obj1.Type)
                            {

                                switch (state.State)
                                {
                                    case ChangeState.stopFalling:
                                     return  "stopFalling";
                                        

                                       
                                    case ChangeState.TowardsLeft:
                                        return "TowardsLeft";
                                        


                                       
                                    case ChangeState.towardsRight:
                                        return "towardsRight";
                                       

                                      
                                    default:
                                        return  null;
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }

        public void TowardsLeft()
        {
          
            foreach (GameObject go in gameObjectslist)
            {
                if (go.Type == GameObjectType.Player)
                {
                    go.getpb().Left = 20; 
                    break; 
                }
            }
        }

        public void TowardsRight()
        {
           
            foreach (GameObject go in gameObjectslist)
            {
                if (go.Type == GameObjectType.Player)
                {
                    go.getpb().Left = 1200; 
                    break; 
                }
            }
        }

        public void StopFalling()
        {
           
            foreach (GameObject go in gameObjectslist)
            {
                if (go.Type == GameObjectType.Player)
                {
                    go.getpb().Top = 10; 
                    break;
                }
            }
        }

    }
}
