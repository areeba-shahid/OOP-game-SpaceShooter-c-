﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkSpaceShooter
{
    public class VerticalPatrol : IMovement
    {

        private int speed;
        private Point boundary;
        private string direction;
        private int offset = 90;

        public  VerticalPatrol(int speed, Point boundary, string direction)
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
        }
        public Point Move(Point location)
        {
            if ((location.Y + offset) >= boundary.Y)
            {
                direction = "up";
            }
            else if (location.Y - speed <= 0)
            {
                direction = "down";
            }
            if (direction == "up")
            {
                location.Y -= speed;

            }
            else
            {
                location.Y += speed;

            }
            return location;

        }
    }
}
