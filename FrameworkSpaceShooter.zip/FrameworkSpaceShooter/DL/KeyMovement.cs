﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EZInput;

namespace FrameworkSpaceShooter
{
    public class KeyMovement : IMovement
    {

        private int speed;
        private System.Drawing.Point boundary; 
        private int offset;

        public KeyMovement(int speed, System.Drawing.Point boundary, int offset)
        {
            this.speed = speed;
            this.boundary = boundary;
            this.offset = offset;
        }
        public System.Drawing.Point Move(System.Drawing.Point location)
        {
          
            if (EZInput.Keyboard.IsKeyPressed(Key.RightArrow) && location.X + offset < boundary.X)
            {
                location.X += speed;
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.LeftArrow) && location.X + speed > 10 )
            {
                location.X -= speed;
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.UpArrow) &&location.Y + speed > 10)
            {
                location.Y -= speed;
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.DownArrow) && location.Y + offset < boundary.Y)
            {
                location.Y += speed;
            }
            return location;
        }
    }
}
