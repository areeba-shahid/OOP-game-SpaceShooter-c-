﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsumerGame.Properties;
using EZInput;
using System.Drawing;
using FrameworkSpaceShooter;
using System.Drawing.Text;
using System.Xml.Linq;

namespace ConsumerGame
{
    public partial class Form1 : Form
    {
        Game game;
        private Player playerbullet;
        private enemy1bullets enemy1bullet;
        private int EnemyBulletcurrentTime = 0;
        private int EnemyBulletcreationTime = 20;
        Random random;

        public Form1()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            // a single instance

            game = Game.GetInstance(this);

            //

            int playerX = (this.Width / 2) - 90;
            int playerY = (this.Height / 2) + 150;
            int bulletX = game.playerX + 65;
            int bulletY = game.playerY - 50;

            random = new Random();


            System.Drawing.Point boundary = new System.Drawing.Point(this.Width, this.Height);


           // createObjects
            game.addGameObject(Resources.player,GameObjectType.Player, playerX, playerY, new KeyMovement(8, boundary, 160));
            game.addGameObject(Resources.enemy1,GameObjectType.horizontalenemy, random.Next(0, this.Width - 100), 10, new HorizontalPatrol(10, boundary, "left"));
            game.addGameObject(Resources.enemy2, GameObjectType.verticalenemy, 15, random.Next(0, this.Height - 50), new VerticalPatrol(10, boundary, "down"));
            game.addGameObject(Resources.enemy3, GameObjectType.diagonalenemy, 25, 25, new zigzagmovement(8, boundary, "right"));

            game.addGameObject(null, GameObjectType.Ground, 0, this.ClientSize.Height - 20 , new NoMovement());



            playerbullet = new Player(120, boundary, 50);
            enemy1bullet = new enemy1bullets(120,boundary);


            // Collision Detection

            CollisionDetection cd1 = new CollisionDetection(GameObjectType.Player, GameObjectType.EnemyBullet, GameAction.DecreasePoints);
            CollisionDetection cd2 = new CollisionDetection(GameObjectType.horizontalenemy, GameObjectType.PlayerBullet, GameAction.DecreasePoints);
           CollisionDetection cd3 = new CollisionDetection(GameObjectType.verticalenemy, GameObjectType.PlayerBullet, GameAction.DecreasePoints);
           CollisionDetection cd4 = new CollisionDetection(GameObjectType.diagonalenemy, GameObjectType.PlayerBullet, GameAction.DecreasePoints);
           CollisionDetection cd5 = new CollisionDetection(GameObjectType.Ground, GameObjectType.Player, GameAction.IncreasePoints);


            // Change State
            ChangeMovementDirection state1 = new ChangeMovementDirection(GameObjectType.Ground, GameObjectType.Player, ChangeState.towardsRight);
            ChangeMovementDirection state2 = new ChangeMovementDirection(GameObjectType.Ground, GameObjectType.Player, ChangeState.stopFalling);


            // game.addcollisions(cd1);
            // game.addcollisions(cd2);
            // game.addcollisions(cd3);
            //game.addcollisions(cd4);
            // game.addcollisions(cd5);
            game.addstatechange(state1);
            game.addstatechange(state2);

            // Factory pattern for total number of enmeies and players
            setEnemylabel();
            setPlayerlabel();


        }


        private void GameLoop_Tick(object sender, EventArgs e)
        {
            game.update();
          

           

            System.Drawing.Point boundary = new System.Drawing.Point(this.Width, this.Height);

           
            int enemybulletX = game.enemy1X + 65;
            int enemybulletY = game.enemy1Y + 120;
            EnemyBulletcurrentTime++;

            if (EnemyBulletcurrentTime == EnemyBulletcreationTime) 
            {
                
                game.addenemybulletsasobjects(Resources.enemybullets1,GameObjectType.EnemyBullet, enemybulletX, enemybulletY, enemy1bullet);
                EnemyBulletcurrentTime = 0;

            }


            int bulletX = game.playerX + 65;
            int bulletY = game.playerY - 50;

            if (EZInput.Keyboard.IsKeyPressed(Key.Enter))
            {
                game.addplayerbulletsasobjects(Resources.playerbullet,GameObjectType.PlayerBullet, bulletX, bulletY, playerbullet);
            }

          string state =   game.collisionForStateCheckingToUpdate();

            if(state == "stopFalling")
            {
                game.StopFalling();
            }
            if (state == "TowardsLeft")
            {
                game.TowardsLeft();
            }
            if (state == "towardsRight")
            {
                game.TowardsRight();
            }

            if (EZInput.Keyboard.IsKeyPressed(Key.Backspace))
            {
                exit();
            }

        }

        private void setEnemylabel()
        {

            int count = GameObjectFactory.GetObjectCount(GameObjectType.horizontalenemy) + GameObjectFactory.GetObjectCount(GameObjectType.verticalenemy) + GameObjectFactory.GetObjectCount(GameObjectType.diagonalenemy);
            enemycount.Text ="EnemyCount  :"+ count.ToString();
        }
        private void setPlayerlabel()
        {
            int count = GameObjectFactory.GetObjectCount(GameObjectType.Player);
            playercount.Text = "PlayerCount :" + count.ToString();
        }
        private void exit()
        {
            this.Hide();
            form2 form = new form2(Resources.gameover);
            form.ShowDialog();
        }
    }
    

    }
